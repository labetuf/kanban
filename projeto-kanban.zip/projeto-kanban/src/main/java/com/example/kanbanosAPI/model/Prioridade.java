package com.example.kanbanosAPI.model;

public enum Prioridade {
    BAIXA,
    MEDIA,
    ALTA
}
