package com.example.kanbanosAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KanbanosApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
